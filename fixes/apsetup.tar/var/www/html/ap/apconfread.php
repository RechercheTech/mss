<?php
$file = "/var/www/ap/ap.conf";

$ar = parse_ini_file("/var/www/ap/ap.conf");
?>
